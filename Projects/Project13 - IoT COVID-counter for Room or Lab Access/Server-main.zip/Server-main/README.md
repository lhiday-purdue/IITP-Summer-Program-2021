# Covid 19 Counter Server

# Develop list

1. SignUp (Clear)
2. Login (Processing)

# Depedencies List

1. lombok
2. Mybatis
3. logback
4. zxing
5. spring security