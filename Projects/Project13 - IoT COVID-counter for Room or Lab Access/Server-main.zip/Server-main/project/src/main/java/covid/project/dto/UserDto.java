package covid.project.dto;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//Vo와 비슷

@Getter
@Setter
@NoArgsConstructor
@ToString

public class UserDto {

    private String identificationNumber;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
    private String password;
    private String token;


}
