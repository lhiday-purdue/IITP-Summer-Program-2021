package covid.project.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class RoomDto {
    private int idx;
    private String buildingName;
    private String roomNumber;
    private int managerNumber;
    private int maximum_capacity;
    private int currentNumberOfPeople;
    private String openTime;
    private String closeTime;

}
