package covid.project.mapper;

import covid.project.dto.UserDto;
import org.apache.ibatis.annotations.Mapper;

// DAO 와 비슷
@Mapper
public interface UserMapper {
    void join(UserDto userDto);
}

@Mapper
public interface userLogin{
    void login(UserDto) {

    }
}