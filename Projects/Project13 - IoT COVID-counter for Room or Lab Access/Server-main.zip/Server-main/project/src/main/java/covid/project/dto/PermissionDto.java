package covid.project.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class PermissionDto {

    private int idx; // Room number
    private String userId; // identificationNumber
    private String permissionStartDate;
    private String permissionEndDate;

}
