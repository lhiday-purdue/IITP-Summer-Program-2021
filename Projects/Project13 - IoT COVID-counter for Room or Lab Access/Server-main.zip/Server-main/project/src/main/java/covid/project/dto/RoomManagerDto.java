package covid.project.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class RoomManagerDto {
    private int managerNumber;
    private String managerName;
    private String phoneNumber;
    private String email;
}
