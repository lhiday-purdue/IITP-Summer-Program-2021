package covid.project.service;

import covid.project.dto.UserDto;
import covid.project.mapper.QrMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class QrService  {

    @Autowired
    QrMapper qrMapper;

    public String QRGenerator(UserDto userDto) {
        return userDto.getIdentificationNumber();
    }

}
