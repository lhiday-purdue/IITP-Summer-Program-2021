package covid.project.service;

import covid.project.dto.UserDto;
import covid.project.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.Enumeration;
import java.util.Hashtable;

@Service
public class UserService {

    @Autowired
    UserMapper userMapper;

    @Autowired
    private static Hashtable<String, String> loginUsers = new Hashtable<String, String>();

    public String join(UserDto userDto) {
        userMapper.join(userDto);
        return userDto.getIdentificationNumber();
    }

    public boolean userLogin(UserDto userDto, HttpSession session)
            throws Exception {
        boolean isLogin = isLogin(userDto.getIdentificationNumber());
        if (!isLogin) {
            boolean result = userMapper.;
            if (result) {
                setSession(session, userDto); }
            return result; }
        return !isLogin;
    }

    public void setSession(HttpSession session, UserDto userDto) {
        loginUsers.put(session.getId(), userDto.getIdentificationNumber());
        session.setAttribute("IdentificationNumber", userDto.getIdentificationNumber());
    }


    public boolean isLogin(String id) {
        boolean isLogin = false;
        Enumeration<String> e = loginUsers.keys();
        String key = ""; while (e.hasMoreElements()) {
            key = (String) e.nextElement();
            if (id.equals(loginUsers.get(key))) isLogin = true;
        } return isLogin;
    }


}
