package covid.project.controller;

import covid.project.dto.UserDto;
import covid.project.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Map;


@Slf4j
@RequestMapping("/users")
@RestController
public class UserController {

    private UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/new")
    public ModelAndView join() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("html/signup");
        return modelAndView;
    }

    @PostMapping(value = "/new")
    public String JoIn(UserDto userDto)
            throws Exception {
        log.info("User Injection Data : " + userDto.toString());
        userService.join(userDto);
        return "redirect:/";
    }
    @RequestMapping("/login")
    public ModelAndView userLogin(@ModelAttribute UserDto userdto, HttpSession session)
            throws Exception {
        boolean result = userService.userLogin(userdto, session);
        ModelAndView mav = new ModelAndView();
        if (result == true) {
            mav.setViewName("redirect:/board/list");
        } else {
            mav.setViewName("/user/UserLogin");
        } return mav;
    }
}



/*    @RequestMapping("/login")
    public ModelAndView userLogin(@ModelAttribute UserDto dto, HttpSession session)
            throws Exception {

    }
}*/

