import RPi.GPIO as GPIO
import time

buzzer=18
labNum=0
Max=5
cnt=0


print("---------------")
print("|Program Start|")
print("---------------")


GPIO.setmode(GPIO.BCM)
GPIO.setup(buzzer, GPIO.OUT)
GPIO.setwarnings(False)

def Alert() :
    pwm.start(50.0)
    for cnt in range (0,3) :
        pwm.ChangeFrequency(330)
        time.sleep(0.5)
        pwm.ChangeFrequency(262)
        time.sleep(0.5)
    pwm.stop()
    

pwm = GPIO.PWM(buzzer, 1.0)

while True:
    
    print("1. Alert")
    print("2. Add Person")
    print("3. Remove Person")
    print("4. Exit")
    print("-------------------")
    selectNum =int(input("Choose Number :"))
    
    if selectNum == 1 :
        Alert()
    elif selectNum == 2 :
        labNum = labNum + 1
    elif selectNum == 3 :
        labNum = labNum - 1
    elif selectNum == 4 :
        break
    else :
        print("wrong number. Try again")

    print("\nNumber of people currently in the laboratory")
    print(labNum)
    print("")

    while labNum > Max :
        Alert()
        labNum = labNum - 1
        print("\nNumber of people currently in the laboratory")
        print(labNum)
        print("")
        if labNum <= Max :
            break

GPIO.cleanup()
